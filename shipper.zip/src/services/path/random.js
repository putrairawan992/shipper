const USER = "/api";

export const PATH_RANDOM = {
    USER
}