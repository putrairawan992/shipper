// import createBrowserHistory from 'history/createBrowserHistory';
import { createBrowserHistory } from 'history'

export default createBrowserHistory();
