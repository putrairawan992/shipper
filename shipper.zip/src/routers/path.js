const HOME_BERANDA = "/";
const DRIVER_MANAGEMENT = "/driver-management";
const PICKUP = "/pickup";

const PATH_URL = {
  HOME_BERANDA,
  DRIVER_MANAGEMENT,
  PICKUP,
};

export default PATH_URL;
