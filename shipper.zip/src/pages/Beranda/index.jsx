import React from 'react';

function Beranda(props) {
    return (
        <div>
            <h2>Halaman Beranda</h2>
        </div>
    );
}

export default Beranda;