import React from 'react';

function Pickup(props) {
    return (
        <div>
            <h2>Halaman Pickup</h2>
        </div>
    );
}

export default Pickup;